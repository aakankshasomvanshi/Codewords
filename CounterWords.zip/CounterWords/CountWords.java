package com.countwords;

import java.util.ArrayList;

public class CountWords {

	public static void main(String[] args) {

		FileUtility fileUtility = new FileUtility();
		ArrayList<String> finalMatchingWordList = null;

		try
		{
			/* Calling 'returnMatchWordListAndDispWordsAndTotalCount' method by passing business rule defined value */
			finalMatchingWordList = (ArrayList<String>) fileUtility.retMatWordListAndDispWordsAndTCnt(
					ConstantConfig.startWordFrom, ConstantConfig.minWordLenth);
		} catch (Exception e) {
			System.out.println(ConstantConfig.fileNotFoundExceptionMessage
					+ ConstantConfig.inputFilePath);
		}
	}
}
