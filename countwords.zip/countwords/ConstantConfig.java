package com.countwords;
/*
 * Class Name : ConstantConfig.Java
 * Date of Creation : 17-03-2022
 * Description : Use to define constant value which can be change in future
 * and no impact on business logic.
 * */

public class ConstantConfig {

	// for multiple spaces between two words. Different separator can also be used
	public static final String separator = "\\s+";
	public static final char startWordFrom = 'm'; /*Word Start with Define Letter */
	public static final int minWordLenth = 5; /* Min lenth of matching word */
	public static final String inputFilePath="C:\\Test\\InputDataFile.txt"; /* Input file location*/
	public static final String fileNotFoundExceptionMessage ="File Not found on predefine Location. i.e ";/*Validation Exception*/
}
